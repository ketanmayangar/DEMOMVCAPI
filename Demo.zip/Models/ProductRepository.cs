﻿using MVCwithWebAPI.Service;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace MVCwithWebAPI.Models
{
    public class ProductRepository : IProductRepository
    {
       
        public async Task Add(Product product)
        {
            product.ProductId = 0;
            DBService dBService = new DBService();
            dBService.SaveProduct(product);
        }
        public async Task<Product> GetProduct(string id)
        {
            try
            {
                DBService dBService = new DBService();
                Product product = dBService.GetProductById(Int32.Parse(id));
                if (product == null)
                {
                    return null;
                }
                return product;
            }
            catch
            {
                throw;
            }
        }
        public async Task<IEnumerable<Product>> GetProducts()
        {
            try
            {
                DBService dBService = new DBService();
                var products = dBService.GetProducts();
                return products.AsQueryable();
            }
            catch
            {
                throw;
            }
        }
        public async Task Update(Product product)
        {
           
            DBService dBService = new DBService();
            dBService.SaveProduct(product);
        }
        public async Task Delete(string id)
        {
            try
            {
               
                DBService dBService = new DBService();
                dBService.DeleteProduct(Int32.Parse(id));
            }
            catch
            {
                throw;
            }
        }
    }
}