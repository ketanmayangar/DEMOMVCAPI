﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using MVCwithWebAPI.Models;


namespace MVCwithWebAPI.Service
{
    public class DBService
    {
        ConnectionStringSettings ConnectionString = ConfigurationManager.ConnectionStrings["SqlConn"];
        public List<Product> GetProducts()
        {
            List<Product> products = new List<Product>();
            using (SqlConnection sql = new SqlConnection(ConnectionString.ToString()))
            {
                //products = sql.Query<Product>("Select * from Product").ToList();
                sql.Open();
                SqlCommand sqlCommand = new SqlCommand("Select * from Product", sql);
                //products = sql.GetList<Product>().ToList();
                GenericRepo<Product> genericRepo = new GenericRepo<Product>();
                products = genericRepo.getList(sqlCommand.ExecuteReader());
            }
            return products;
        }


        public List<ProductCategory> GetCategories()
        {
            List<ProductCategory> productCategories = new List<ProductCategory>();
            using (SqlConnection sqlConnection = new SqlConnection(ConnectionString.ToString()))
            {
                sqlConnection.Open();
                //productCategories = sqlConnection.GetList<ProductCategory>().ToList();
                SqlCommand sqlCommand = new SqlCommand("Select * from ProductCategory", sqlConnection);
                GenericRepo<ProductCategory> genericRepo = new GenericRepo<ProductCategory>();
                productCategories = genericRepo.getList(sqlCommand.ExecuteReader());
            }
            return productCategories;
        }

        public Product GetProductById(int ProductId)
        {
            Product product = new Product();
            using (SqlConnection sql = new SqlConnection(ConnectionString.ToString()))
            {
                sql.Open();
                SqlCommand sqlCommand = new SqlCommand("Select * from Product where ProductId = " + ProductId, sql);
                GenericRepo<Product> genericRepo = new GenericRepo<Product>();
                product = genericRepo.getList(sqlCommand.ExecuteReader()).First();
            }
            return product;
        }

        public bool SaveProduct(Product product)
        {
            int returnInt;
            using (SqlConnection sql = new SqlConnection(ConnectionString.ToString()))
            {
                sql.Open();
                SqlCommand sqlCommand = null;
                if (product.ProductId > 0)
                {
                    sqlCommand = new SqlCommand("Update Product set ProdCatID = " + product.ProdCatId + ", ProdName = '" + product.ProdName + "', ProdDescription = '" + product.ProdDescription + "' where ProductId = " + product.ProductId, sql);
                }
                else
                {
                    sqlCommand = new SqlCommand("insert into Product(ProdCatID,ProdName,ProdDescription) values (" + product.ProdCatId + ", '" + product.ProdName + "','" + product.ProdDescription + "')", sql);
                }

                returnInt = sqlCommand.ExecuteNonQuery();
            }
            return returnInt == 1 ? true : false;
        }

        public bool DeleteProduct(int ProductId)
        {
            int returnInt = 0;
            using (SqlConnection sql = new SqlConnection(ConnectionString.ToString()))
            {
                sql.Open();
                SqlCommand sqlCommand = null;
                if (ProductId > 0)
                {
                    sqlCommand = new SqlCommand("Delete from Product where ProductId = " + ProductId, sql);
                    returnInt = sqlCommand.ExecuteNonQuery();
                }
            }
            return returnInt == 1 ? true : false;
        }

    }

    public class GenericRepo<T>
    {
        public virtual List<T> getList(SqlDataReader reader)
        {
            var results = new List<T>();
            var properties = typeof(T).GetProperties();

            while (reader.Read())
            {
                var item = Activator.CreateInstance<T>();
                foreach (var property in typeof(T).GetProperties())
                {
                    if (!reader.IsDBNull(reader.GetOrdinal(property.Name)))
                    {
                        Type convertTo = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                        property.SetValue(item, Convert.ChangeType(reader[property.Name], convertTo), null);
                    }
                }
                results.Add(item);
            }
            return results;
        }
    }
}
