﻿using MVCwithWebAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Http;

namespace MVCwithWebAPI.Controllers
{
    public class ECommerceDemoApiController : ApiController
    {
        private readonly IProductRepository _iProductRepository = new ProductRepository();

        [HttpGet]
        [Route("api/ECommerceDemo/Get")]
        public async Task<IEnumerable<Product>> Get()
        {
            return await _iProductRepository.GetProducts();
        }

        [HttpPost]
        [Route("api/ECommerceDemo/Create")]
        public async Task CreateAsync([FromBody]Product product)
        {
            if (ModelState.IsValid)
            {
                await _iProductRepository.Add(product);
            }
        }

        [HttpGet]
        [Route("api/ECommerceDemo/Details/{id}")]
        public async Task<Product> Details(string id)
        {
            var result = await _iProductRepository.GetProduct(id);
            return result;
        }

        [HttpPut]
        [Route("api/ECommerceDemo/Edit")]
        public async Task EditAsync([FromBody]Product product)
        {
            if (ModelState.IsValid)
            {
                await _iProductRepository.Update(product);
            }
        }

        [HttpDelete]
        [Route("api/ECommerceDemo/Delete/{id}")]
        public async Task DeleteConfirmedAsync(string id)
        {
            await _iProductRepository.Delete(id);
        }
    }
}