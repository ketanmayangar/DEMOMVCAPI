﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace MVCwithWebAPI.Models
{
    public interface IProductRepository
    {
        Task Add(Product product);
        Task Update(Product product);
        Task Delete(string id);
        Task<Product> GetProduct(string id);
        Task<IEnumerable<Product>> GetProducts();
    }
}
